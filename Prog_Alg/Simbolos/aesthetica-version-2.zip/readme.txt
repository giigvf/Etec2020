Aesthetica Icon Set, version 2.0
http://dryicons.com/free-icons/preview/aesthetica-version-2/

Information
----------------------

This icon set contains 181 quality icons in the following formats:
	Transparent PNG
		16 x 16 px
		24 x 24 px
		32 x 32 px
		48 x 48 px
		128 x 128 px
	


Licensing
----------------------

This work is licensed under a Creative Commons Attribution 3.0 License. 
This means that you can do pretty much everything. 
However, you must include a link back to http://dryicons.com/ in your credits. 
Please contact us at contact@dryicons.com to discuss the licensing.

